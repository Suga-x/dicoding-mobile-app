package com.example.dcodingsubmission;

public class Band {
    private String namaBand;

    public String getNamaBand() {
        return namaBand;
    }

    public void setNamaBand(String namaBand) {
        this.namaBand = namaBand;
    }

    public String getDescBand() {
        return descBand;
    }

    public void setDescBand(String descBand) {
        this.descBand = descBand;
    }

    public int getFotothumbnail() {
        return fotothumbnail;
    }

    public void setFotothumbnail(int fotothumbnail) {
        this.fotothumbnail = fotothumbnail;
    }

    public int getFotoPoster() {
        return fotoPoster;
    }

    public void setFotoPoster(int fotoPoster) {
        this.fotoPoster = fotoPoster;
    }

    private  String descBand;
    private int fotothumbnail;
    private int fotoPoster;
}
